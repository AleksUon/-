﻿#include <iostream>
using namespace std;

// Структура узла списка
struct Node {
    int data;
    Node* next;
    Node(int val) : data(val), next(nullptr) {}
};

// Функция для вставки нового узла перед первым узлом в списке
void insertBeforeFirst(Node*& head, int val) {
    Node* newNode = new Node(val);
    newNode->next = head;
    head = newNode;
}

// Функция для удаления узла по ключу
void deleteByKey(Node*& head, int key) {
    if (head == nullptr) return;

    if (head->data == key) {
        Node* temp = head;
        head = head->next;
        delete temp;
        return;
    }

    Node* current = head;
    while (current->next != nullptr && current->next->data != key) {
        current = current->next;
    }

    if (current->next != nullptr) {
        Node* temp = current->next;
        current->next = current->next->next;
        delete temp;
    }
}

// Функция для вывода списка в консоль
void printList(Node* head) {
    while (head != nullptr) {
        cout << head->data << " ";
        head = head->next;
    }
    cout << endl;
}

// Функция для создания нового списка вручную
Node* createManualList() {
    Node* head = nullptr;
    int n;
    cout << "Введите количество элементов списка: ";
    cin >> n;
    cout << "Введите элементы списка: ";
    for (int i = 0; i < n; ++i) {
        int val;
        cin >> val;
        insertBeforeFirst(head, val);
    }
    return head;
}

// Функция для переформирования списка, перемещая часть списка, начиная с заданной позиции, в начало
void movePartToFront(Node*& head, int startPosition) {
    if (head == nullptr || head->next == nullptr) return;

    Node* current = head;
    Node* prev = nullptr;
    int count = 0;

    // Находим узел, предшествующий позиции startPosition
    while (current != nullptr && count != startPosition) {
        prev = current;
        current = current->next;
        count++;
    }

    if (current == nullptr) return; // Если позиция startPosition выходит за пределы списка

    // Устанавливаем следующий узел после prev как nullptr
    prev->next = nullptr;

    // Находим последний узел нового списка
    Node* newTail = current;
    while (newTail->next != nullptr) {
        newTail = newTail->next;
    }

    // Присоединяем оставшуюся часть исходного списка к новому списку
    newTail->next = head;
    head = current;
}


// Функция для вставки узла в упорядоченный по не возрастанию список
void insertInOrder(Node*& head, int val) {
    Node* newNode = new Node(val);

    // Если список пуст или новый элемент меньше первого элемента, вставляем его перед первым элементом
    if (head == nullptr || val <= head->data) {
        newNode->next = head;
        head = newNode;
        return;
    }

    // Иначе ищем место для вставки в порядке убывания
    Node* current = head;
    while (current->next != nullptr && current->next->data > val) {
        current = current->next;
    }

    // Вставляем новый узел после узла, перед которым он должен находиться
    newNode->next = current->next;
    current->next = newNode;
}

// Функция для удаления из списка L2 всех повторяющихся значений
void removeDuplicates(Node*& head) {
    if (head == nullptr || head->next == nullptr) return;

    Node* current = head;

    while (current != nullptr && current->next != nullptr) {
        if (current->data == current->next->data) {
            Node* temp = current->next;
            current->next = current->next->next;
            delete temp;
        }
        else {
            current = current->next;
        }
    }
}

int main() {
    setlocale(LC_ALL, "Rus");
    Node* list = nullptr;
    Node* orderedList = nullptr; // Переместил объявление сюда и инициализировал значением nullptr
    int Choice;

    // Меню выбора типа ввода данных
    cout << "Выберите тип ввода данных:" << endl;
    cout << "1. Использовать уже существующее данные" << endl;
    cout << "2. С клавиатуры" << endl;

    cout << "Введите номер выбранного типа ввода данных: ";
    cin >> Choice;

    switch (Choice) {
    case 1:
        insertBeforeFirst(list, 3);
        insertBeforeFirst(list, 2);
        insertBeforeFirst(list, 2);
        insertBeforeFirst(list, 1);
        insertBeforeFirst(list, 1);
        break;

    case 2:
        // Ввод данных вручную
        int value;
        cout << "Введите элементы для списка (для завершения введите -1): ";
        while (cin >> value && value != -1) {
            insertBeforeFirst(list, value);
        }
        break;
    default:
        cout << "Ошибка" << endl;
        return 0;
    }
    cout << "Исходный список: ";
    printList(list);

    int operationChoice;

    // Меню выбора операции
    cout << "Выберите операцию:" << endl;
    cout << "0. Завершить программу" << endl;
    cout << "1. Вставить новый узел перед первым узлом" << endl;
    cout << "2. Удалить узел по ключу" << endl;
    cout << "3. Перемещение части в начало" << endl;
    cout << "4. Вставить новый узел в упорядоченный по неубыванию список." << endl;
    cout << "5. Удалить из списка все повторяющиеся значения, оставляя только по одному из каждого уникального значения" << endl;
    cout << "6. Вывести списки в консоль" << endl;

    do {
        cout << "Введите номер выбранной операции: ";
        cin >> operationChoice;

        switch (operationChoice) {
        case 0:
            return 0; // Завершить программу
        case 1:
            // Вставка нового узла перед первым узлом
            int valueToInsert;
            cout << "Введите значение для вставки: ";
            cin >> valueToInsert;
            insertBeforeFirst(list, valueToInsert);
            break;
        case 2:
            // Удаление узла по ключу
            int keyToDelete;
            cout << "Введите ключ для удаления: ";
            cin >> keyToDelete;
            deleteByKey(list, keyToDelete);
            break;
        case 3: {
            // перемещения части в начало
            movePartToFront(list, 2);
            cout << "Список после перемещения части в начало: ";
            printList(list);
            break;
        }
        case 4:
            // список L2
            insertInOrder(orderedList, 4);
            insertInOrder(orderedList, 1);
            insertInOrder(orderedList, 3);
            insertInOrder(orderedList, 2);
            insertInOrder(orderedList, 2);
            cout << "Упорядоченный список: ";
            printList(orderedList);
            break;
        case 5:
            // удаления повторяющихся элементов
            removeDuplicates(orderedList);
            cout << "Список после удаления повторяющихся элементов: ";
            printList(orderedList);
            break;
        case 6:
            cout << "Список: ";
            printList(list);
            break;
        default:
            cout << "Ошибка" << endl;
            break;
        }
    } while (operationChoice != 0);

    return 0;
}

