﻿#include <iostream>
using namespace std;

// Структура узла списка
struct Node {
    int data;
    Node* next;
    Node(int val) : data(val), next(nullptr) {}
};

// Функция для вставки нового узла перед первым узлом в списке
void insertBeforeFirst(Node*& head, int val) {
    Node* newNode = new Node(val);
    newNode->next = head;
    head = newNode;
}

// Функция для удаления узла по ключу
void deleteByKey(Node*& head, int key) {
    if (head == nullptr) return;

    if (head->data == key) {
        Node* temp = head;
        head = head->next;
        delete temp;
        return;
    }

    Node* current = head;
    while (current->next != nullptr && current->next->data != key) {
        current = current->next;
    }

    if (current->next != nullptr) {
        Node* temp = current->next;
        current->next = current->next->next;
        delete temp;
    }
}

// Функция для вывода списка в консоль
void printList(Node* head) {
    while (head != nullptr) {
        cout << head->data << " ";
        head = head->next;
    }
    cout << endl;
}

// Функция для объединения списков L1 и L2, исключая повторяющиеся элементы
Node* mergeLists(Node* L1, Node* L2) {
    Node* result = nullptr;
    Node* tail = nullptr;

    while (L1 != nullptr) {
        bool found = false;
        Node* temp = result;
        while (temp != nullptr) {
            if (temp->data == L1->data) {
                found = true;
                break;
            }
            temp = temp->next;
        }
        if (!found) {
            if (result == nullptr) {
                result = new Node(L1->data);
                tail = result;
            }
            else {
                tail->next = new Node(L1->data);
                tail = tail->next;
            }
        }
        L1 = L1->next;
    }

    while (L2 != nullptr) {
        bool found = false;
        Node* temp = result;
        while (temp != nullptr) {
            if (temp->data == L2->data) {
                found = true;
                break;
            }
            temp = temp->next;
        }
        if (!found) {
            if (result == nullptr) {
                result = new Node(L2->data);
                tail = result;
            }
            else {
                tail->next = new Node(L2->data);
                tail = tail->next;
            }
        }
        L2 = L2->next;
    }

    return result;
}

// Функция для удаления из списка L1 узлов на четных позициях
void deleteEvenPositionNodes(Node*& head) {
    if (head == nullptr || head->next == nullptr) return;

    Node* current = head;
    Node* prev = nullptr;
    int count = 0;

    while (current != nullptr) {
        if (count % 2 == 0) {
            if (current == head) {
                head = head->next;
                delete current;
                current = head;
            }
            else {
                prev->next = current->next;
                delete current;
                current = prev->next;
            }
        }
        else {
            prev = current;
            current = current->next;
        }
        count++;
    }
}

// Функция для вставки нового узла в список L2 после каждой пары узлов
void insertAfterPairs(Node*& head) {
    Node* current = head;

    while (current != nullptr && current->next != nullptr) {
        int sum = current->data + current->next->data;
        Node* newNode = new Node(sum);
        newNode->next = current->next->next;
        current->next->next = newNode;
        current = current->next->next;
    }
}

// Функция для освобождения памяти, выделенной под узлы списка
void deleteList(Node*& head) {
    while (head != nullptr) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
}


int main() {
    setlocale(LC_ALL, "Rus");
    // Пример использования функций
    Node* list1 = nullptr;
    Node* list2 = nullptr;

    int Choice;

    // Меню выбора типа ввода данных
    cout << "Выберите тип ввода данных:" << endl;
    cout << "1. Ввести данные вручную" << endl;
    cout << "2. Использовать уже имеющиеся данные" << endl;

    cout << "Введите номер выбранного типа ввода данных: ";
    cin >> Choice;

    switch (Choice) {
    case 1:
        // Ввод данных вручную
        int value;
        cout << "Введите элементы для списка 1 (для завершения введите -1): ";
        while (cin >> value && value != -1) {
            insertBeforeFirst(list1, value);
        }
        cout << "Введите элементы для списка 2 (для завершения введите -1): ";
        while (cin >> value && value != -1) {
            insertBeforeFirst(list2, value);
        }
        break;
    case 2:
        // Использование уже имеющихся данных
        insertBeforeFirst(list1, 1);
        insertBeforeFirst(list1, 2);
        insertBeforeFirst(list1, 3);

        insertBeforeFirst(list2, 2);
        insertBeforeFirst(list2, 3);
        insertBeforeFirst(list2, 4);
        break;
    default:
        cout << "Неверный выбор типа ввода данных." << endl;
        return 0;
    }

    int operationChoice;

    // Меню выбора операции
    cout << "Выберите операцию:" << endl;
    cout << "0. Завершить программу" << endl;
    cout << "1. Вставить новый узел перед первым узлом" << endl;
    cout << "2. Удалить узел по ключу" << endl;
    cout << "3. Объединить списки, исключая повторяющиеся элементы" << endl;
    cout << "4. Удалить узлы на четных позициях из списка L1" << endl;
    cout << "5. Вставить новый узел после каждой пары узлов в списке L2" << endl;
    cout << "6. Вывести списки в консоль" << endl;

    do {
        cout << "Введите номер выбранной операции: ";
        cin >> operationChoice;

        switch (operationChoice) {
        case 0:
            return 0; // Завершить программу
        case 1:
            // Вставка нового узла перед первым узлом
            int valueToInsert;
            cout << "Введите значение для вставки: ";
            cin >> valueToInsert;
            insertBeforeFirst(list1, valueToInsert);
            break;
        case 2:
            // Удаление узла по ключу
            int keyToDelete;
            cout << "Введите ключ для удаления: ";
            cin >> keyToDelete;
            deleteByKey(list1, keyToDelete);
            break;
        case 3: {
            // Объединение списков, исключая повторяющиеся элементы
            Node* mergedList = mergeLists(list1, list2);
            cout << "Объединенный список: ";
            printList(mergedList);
            deleteList(mergedList); // Освободить память
            break;
        }
        case 4:
            // Удаление узлов на четных позициях
            deleteEvenPositionNodes(list1);
            break;
        case 5:
            // Вставка нового узла после каждой пары узлов
            insertAfterPairs(list2);
            break;
        case 6:
            // Вывод списка в консоль
            cout << "Список 1: ";
            printList(list1);
            cout << "Список 2: ";
            printList(list2);
            break;
        default:
            cout << "Неверный выбор операции." << endl;
            break;
        }
    } while (operationChoice != 0);

    // Освобождение памяти, выделенной под узлы списка
    deleteList(list1);
    deleteList(list2);

    return 0;
}