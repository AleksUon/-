﻿#include <iostream>
#include <vector>
#include <algorithm>

void mergeSort(std::vector<int>& arr) {
    if (arr.size() <= 1)
        return;

    int mid = arr.size() / 2;
    std::vector<int> left(arr.begin(), arr.begin() + mid);
    std::vector<int> right(arr.begin() + mid, arr.end());

    mergeSort(left);
    mergeSort(right);

    int i = 0, j = 0, k = 0;
    while (i < left.size() && j < right.size()) {
        if (left[i] <= right[j])
            arr[k++] = left[i++];
        else
            arr[k++] = right[j++];
    }

    while (i < left.size())
        arr[k++] = left[i++];

    while (j < right.size())
        arr[k++] = right[j++];
}

int main() {
    std::vector<int> arr = { 8, 2, 13, 4, 15, 6, 9, 11, 3, 7, 5, 10, 1, 12, 14 };

    mergeSort(arr);

    for (int num : arr)
        std::cout << num << ' ';

    return 0;
}

/*
#include <fstream>
#include <vector>
#include <algorithm>
#include <chrono>

void naturalMergeSort(std::vector<int>& arr) {
    if (arr.size() <= 1)
        return;

    std::vector<int> temp(arr.size());
    for (int width = 1; width < arr.size(); width *= 2) {
        for (int i = 0; i < arr.size(); i += 2 * width) {
            auto middle = i + width < arr.size() ? i + width : arr.size();
            auto end = i + 2 * width < arr.size() ? i + 2 * width : arr.size();

            std::merge(arr.begin() + i, arr.begin() + middle, arr.begin() + middle, arr.begin() + end, temp.begin() + i);
        }
        std::copy(temp.begin(), temp.end(), arr.begin());
    }
}

int main() {
    std::vector<int> arr = {17, 31, 5, 59, 13, 41, 43, 67, 11, 23, 29, 47, 3, 7, 71, 2, 19, 57, 37, 61};

    naturalMergeSort(arr);

    for (int num : arr)
        std::cout << num << ' ';

    return 0;
}
*/